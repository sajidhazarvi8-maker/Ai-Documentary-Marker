# AI Documentary Maker — Free browser build

## Install / publish
1. Extract this ZIP.
2. Open your GitHub repository and upload/replace these three files in the repository root: `index.html`, `manifest.webmanifest`, `sw.js`.
3. Commit changes. Keep GitHub Pages enabled. Open your existing Pages website and refresh.
4. On Android Chrome: browser menu ⋮ → Add to Home screen / Install app.

## Included
- Script and Urdu voice-recording workflows.
- Script/transcript scene splitting; voice duration estimated by transcript word count.
- Wikimedia Commons image search and user image uploads.
- Full captions or important-word highlight; white/yellow/green/red; bold fonts; bottom/center; 16:9 and 9:16.
- Upload original narration, background music and sound effects; browser slideshow recording/export.

## Limits
This static GitHub Pages build does not generate AI video/images itself and does not automatically transcribe Urdu speech. Voice workflow requires you to paste a transcript. It uses browser recording and can export WebM or MP4 depending on browser support. Mobile memory, audio codecs, and long-video recording may limit output. Commons images have individual licences; open the source link and check attribution/usage terms. Music must be appropriately licensed; some YouTube Audio Library tracks require attribution.
